define( {
	// Generic.
	OK:     "OK",
	CANCEL: "Annulla",
	RESET:  "Resetta",
	
	// Menu.
	MENU_ON_SAVE:   "Aggiungi i prefissi al salvataggio",
	MENU_SELECTION: "Aggiungi i prefissi al testo selezionato",
	MENU_SETTINGS:  "Impostazioni Autoprefixer...",
	
	// Settings dialog.
	SETTINGS_TITLE:          "Impostazioni Autoprefixer",
	SETTINGS_VISUAL_CASCADE: "Indenta a cascata",
	SETTINGS_BROWSERS:       "Browsers"
} );
