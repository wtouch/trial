(function () {
    "use strict";
    
    exports.init = function () {

        require("./backend");
    };

}());