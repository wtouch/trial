// This file should error when you set flags fir v8 to --use-strict:
// ReferenceError: foo is not defined

foo = "bar";
