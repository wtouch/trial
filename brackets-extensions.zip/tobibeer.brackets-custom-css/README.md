### brackets-custom-css

Here's a no-voodoo extension that does what it says and only that.<br>
Simply modify and apply custom css styles to brackets ui...

1. open **help / extensions folder**
2. go to **user / tobibeer.brackets-custom-css**
3. open **styles.css**
    * use F12 (developer tools) to inspect bracket's elements
	* add desired styles
	* save changes
4. reload brackets ui via f5
5. repeat until satisfied

Default styles increase sidebar and outline font size a wee bit.