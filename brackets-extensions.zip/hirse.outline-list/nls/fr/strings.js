/* global define */

define({
    HEADER_TITLE: "Outline",

    TOOLBAR_ICON_TOOLTIP: "Onglet Outline",

    BUTTON_SETTINGS: "Configurer Outline",
    BUTTON_MOVE: "Changer la position de Outline",
    BUTTON_CLOSE: "Fermer Outline",

    COMMAND_SORT: "Liste courte",
    COMMAND_UNNAMED: "Monter les fonctions anonymess",
    COMMAND_ARGS: "Montrer les paramètres"
});

/* Last translated for 41a691e45e34f3ebde20bc5e3fdca8014871490d */
