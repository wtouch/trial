/* global define */

define({
    HEADER_TITLE: "Outline",

    TOOLBAR_ICON_TOOLTIP: "Outline umschalten",

    BUTTON_SETTINGS: "Outline konfigurieren",
    BUTTON_MOVE: "Outline Position ändern",
    BUTTON_CLOSE: "Outline schließen",

    COMMAND_SORT: "Liste sortieren",
    COMMAND_UNNAMED: "Anonyme Funktionen anzeigen",
    COMMAND_ARGS: "Argumente anzeigen"
});

/* Last translated for 41a691e45e34f3ebde20bc5e3fdca8014871490d */
