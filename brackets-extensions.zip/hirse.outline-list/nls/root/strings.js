/* global define */

define({
    HEADER_TITLE: "Outline",

    TOOLBAR_ICON_TOOLTIP: "Toggle Outline",

    BUTTON_SETTINGS: "Configure Outline",
    BUTTON_MOVE: "Toggle Outline Position",
    BUTTON_CLOSE: "Close Outline",

    COMMAND_SORT: "Sort Functions",
    COMMAND_UNNAMED: "Show Unnamed Functions",
    COMMAND_ARGS: "Show Arguments"
});
