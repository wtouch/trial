brackets-grunt
==============

Extension that lists and runs Grunt tasks inside Brackets

![alt tag](http://i.imgur.com/QaMlbHR.png)

